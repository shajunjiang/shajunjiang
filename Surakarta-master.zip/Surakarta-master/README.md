# Surakarta
苏拉卡尔塔棋（Surakarta）  
界面采用java swing框架写成  
运行图：  

![image](https://github.com/xiepl1997/Surakarta/blob/master/images/start.png)

![image](https://github.com/xiepl1997/Surakarta/blob/master/images/game.png)
